<?php
// routes/index.php
// هذا الملف بسيط: فقط يتضمن web.php الذي يسجل المسارات على المتغير $router
require __DIR__ . '/web.php';
